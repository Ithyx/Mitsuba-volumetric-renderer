from typing import List, Tuple
import drjit as dr
import mitsuba as mi
import mitsuba
# TODO: A changer en fonction du mode de rendu
mi.set_variant('cuda_ad_rgb')

class VolumeRendering(mi.SamplingIntegrator):
    def __init__(self, props: mi.Properties) -> None:
        super().__init__(props)
    
    def sample(self, scene: mi.Scene, sampler, ray: mi.RayDifferential3f, medium: mi.Medium = None, active: bool = True) -> Tuple[mi.Color3f, bool, List[float]]:
        # Calcul la premiere intersection
        its = scene.ray_intersect(ray)
        res = dr.zeros(mi.Color3f) # Resultat sous forme de couleur

        # TODO: Verifier si il y a pas un meilleur de faire ca
        #   Je pense qu'en wavefront ou autre mode de rendu, ca devrais marcher
        if(dr.any(its.is_valid())):
            # Creation d'un nouveau rayon allant dans la meme direction
            # origine: l'intersection precedente
            ray2 = its.spawn_ray(ray.d)
            # Calcul de la nouvelle intersection
            its2 = scene.ray_intersect(ray2)
            # Affichage de la distance d'intersection dans la couleur rouge
            res[its2.is_valid()] = mi.Color3f(its2.t/4, 0.0, 0.0)
        return (res, True, [])

# Enregristrement du nouvel integrateur
mi.register_integrator("myvol", lambda props: VolumeRendering(props))

# Creation du dictionnaire de parametre par default
# permet de modifier les valeurs de "default" dans le .xml
params = {}
params["integrator"] = "myvol"
# Chargement de la scene
scene = mi.load_file("scenes/simple.xml", **params)
# Rendu de la scene
original_image = mi.render(scene, spp=128)

# Affichage du resultat
import matplotlib.pyplot as plt
plt.axis('off')
plt.imshow(original_image ** (1.0 / 2.2))
plt.show()

